## shiny-dashboard
 Fullstack open source Shiny and beautiful dashboard application made with with these technologies #MongoDB, #Express, #React &amp; #Nodejs (MERN) and other using UI libraries.

## soooooooooooooonnnnn
